import pdfplumber

with pdfplumber.open("ahca_medicaid.pdf") as pdf:
    for i, page in enumerate(pdf.pages):
        print(f"\n=== PAGE {i+1} ===")
        # Try table extraction first
        tables = page.extract_tables()
        if tables:
            for j, table in enumerate(tables):
                print(f"  TABLE {j+1}:")
                for row in table:
                    print("  |", " | ".join(str(c) if c else "" for c in row))
        else:
            text = page.extract_text()
            if text:
                print(text)
