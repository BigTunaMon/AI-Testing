"""
Parse AHCA PDF and output COUNTY_DATA dict for app.py.
Program-group → age mapping:
  0-18   : SOBRA CHILD + SOBRA CHILD OP + MED EXP 6-18 + MED EXP <1
  19-44  : TANF + UP + MN-TANF + REFUGEE + SOBRA PR WOM + SOBRA PW OP + FP WAIVER
  45-64  : SSI + PMA
  65+    : ELD & DISAB + QMB ONLY + QMB SLMB + MN-SSI + SILVER SAVER RX + QMB QI
"""
import pdfplumber, re, json

COUNTY_META = {
    "ALACHUA":      {"pop": 275487,  "area": 874.3},
    "BAKER":        {"pop": 29210,   "area": 585.3},
    "BAY":          {"pop": 180075,  "area": 763.8},
    "BRADFORD":     {"pop": 28219,   "area": 293.8},
    "BREVARD":      {"pop": 606612,  "area": 1015.9},
    "BROWARD":      {"pop": 1944375, "area": 1209.4},
    "CALHOUN":      {"pop": 14235,   "area": 567.0},
    "CHARLOTTE":    {"pop": 185978,  "area": 680.6},
    "CITRUS":       {"pop": 149657,  "area": 582.9},
    "CLAY":         {"pop": 219252,  "area": 601.3},
    "COLLIER":      {"pop": 375752,  "area": 2025.2},
    "COLUMBIA":     {"pop": 71686,   "area": 797.0},
    "DESOTO":       {"pop": 37106,   "area": 639.4},
    "DIXIE":        {"pop": 16422,   "area": 703.8},
    "DUVAL":        {"pop": 983885,  "area": 763.5},
    "ESCAMBIA":     {"pop": 321905,  "area": 661.2},
    "FLAGLER":      {"pop": 115081,  "area": 485.3},
    "FRANKLIN":     {"pop": 12404,   "area": 534.9},
    "GADSDEN":      {"pop": 45087,   "area": 516.2},
    "GILCHRIST":    {"pop": 18582,   "area": 349.5},
    "GLADES":       {"pop": 13363,   "area": 773.6},
    "GULF":         {"pop": 13639,   "area": 554.9},
    "HAMILTON":     {"pop": 14428,   "area": 515.1},
    "HARDEE":       {"pop": 26919,   "area": 637.4},
    "HENDRY":       {"pop": 42671,   "area": 1152.7},
    "HERNANDO":     {"pop": 193920,  "area": 477.2},
    "HIGHLANDS":    {"pop": 104847,  "area": 1028.3},
    "HILLSBOROUGH": {"pop": 1471968, "area": 1020.3},
    "HOLMES":       {"pop": 19430,   "area": 482.2},
    "INDIAN RIVER": {"pop": 159923,  "area": 503.3},
    "JACKSON":      {"pop": 48472,   "area": 916.4},
    "JEFFERSON":    {"pop": 14252,   "area": 598.4},
    "LAFAYETTE":    {"pop": 8624,    "area": 543.6},
    "LAKE":         {"pop": 385720,  "area": 953.4},
    "LEE":          {"pop": 760822,  "area": 804.6},
    "LEON":         {"pop": 292198,  "area": 667.2},
    "LEVY":         {"pop": 41503,   "area": 1118.0},
    "LIBERTY":      {"pop": 8365,    "area": 835.9},
    "MADISON":      {"pop": 18501,   "area": 692.1},
    "MANATEE":      {"pop": 403253,  "area": 741.0},
    "MARION":       {"pop": 375908,  "area": 1584.0},
    "MARTIN":       {"pop": 161000,  "area": 556.4},
    "MIAMI-DADE":   {"pop": 2701767, "area": 1899.0},
    "MONROE":       {"pop": 74228,   "area": 983.0},
    "NASSAU":       {"pop": 85070,   "area": 652.9},
    "OKALOOSA":     {"pop": 210738,  "area": 936.2},
    "OKEECHOBEE":   {"pop": 40572,   "area": 773.8},
    "ORANGE":       {"pop": 1393452, "area": 903.4},
    "OSCEOLA":      {"pop": 389476,  "area": 1323.5},
    "PALM BEACH":   {"pop": 1496770, "area": 1970.0},
    "PASCO":        {"pop": 561891,  "area": 744.0},
    "PINELLAS":     {"pop": 959107,  "area": 273.8},
    "POLK":         {"pop": 724777,  "area": 1797.7},
    "PUTNAM":       {"pop": 73624,   "area": 722.4},
    "ST. JOHNS":    {"pop": 273425,  "area": 601.2},
    "ST. LUCIE":    {"pop": 328297,  "area": 572.0},
    "SANTA ROSA":   {"pop": 182084,  "area": 1012.1},
    "SARASOTA":     {"pop": 434006,  "area": 571.8},
    "SEMINOLE":     {"pop": 471826,  "area": 308.5},
    "SUMTER":       {"pop": 134952,  "area": 546.2},
    "SUWANNEE":     {"pop": 44417,   "area": 688.2},
    "TAYLOR":       {"pop": 21569,   "area": 1043.1},
    "UNION":        {"pop": 14468,   "area": 240.2},
    "VOLUSIA":      {"pop": 553284,  "area": 1101.2},
    "WAKULLA":      {"pop": 33739,   "area": 607.0},
    "WALTON":       {"pop": 74071,   "area": 1058.2},
    "WASHINGTON":   {"pop": 24509,   "area": 580.5},
}

# Column indices in the table row (0=COUNTY, 1=SSI, 2=ELD&DISAB, 3=SOBRA_CHILD,
# 4=TANF, 5=UP, 6=MN_TANF, 7=REFUGEE, 8=QMB_ONLY, 9=SOBRA_PR_WOM,
# 10=SOBRA_CHILD_OP, 11=SOBRA_PW_OP, 12=PMA, 13=QMB_SLMB, 14=MN_SSI,
# 15=SILVER_SAVER, 16=QMB_QI, 17=MED_EXP_6_18, 18=FP_WAIVER,
# 19=MED_EXP_UNDER_1, 20=TOTAL)
AGE_COLS = {
    "0-18":  [3, 10, 17, 19],
    "19-44": [4, 5, 6, 7, 9, 11, 18],
    "45-64": [1, 12],
    "65+":   [2, 8, 13, 14, 15, 16],
}

SKIP = {"TOTAL REGION", "LAST MONTH", "LAST YEAR", "DIFFERENCE",
        "STATE TOTAL", "OTHER STATES", "UNKNOWN"}

def parse_num(s):
    return int(s.replace(",", "").replace("(", "-").replace(")", "")) if s and s.strip() not in ("", "0") else 0

# Name normalisation: PDF name → dict key
def norm(name):
    n = name.strip().upper()
    if n == "MIAMI DADE":  return "MIAMI-DADE"
    if n == "ST JOHNS":    return "ST. JOHNS"
    if n == "ST LUCIE":    return "ST. LUCIE"
    if n == "SANTA ROSA":  return "SANTA ROSA"
    return n

results = {}

with pdfplumber.open("ahca_medicaid.pdf") as pdf:
    for page in pdf.pages:
        tables = page.extract_tables()
        for table in tables:
            for row in table:
                if not row or not row[0]:
                    continue
                name = str(row[0]).strip().upper()
                if any(name.startswith(s) for s in SKIP):
                    continue
                if name in ("* PROGRAM-GROUP", "COUNTY", "PROGRAM-GROUP"):
                    continue
                # Must have at least 20 numeric cells
                if len(row) < 20:
                    continue
                # Try to parse total (last numeric column)
                try:
                    total = parse_num(str(row[20]))
                except:
                    continue
                if total == 0:
                    continue

                key = norm(name)
                if key not in COUNTY_META:
                    continue

                medicaid = {}
                for age, cols in AGE_COLS.items():
                    medicaid[age] = sum(parse_num(str(row[c])) for c in cols)

                results[key] = {"total": total, "medicaid": medicaid}

# Print the COUNTY_DATA python dict
print("COUNTY_DATA = {")
for cname, meta in sorted(COUNTY_META.items()):
    md = results.get(cname)
    if md:
        m = md["medicaid"]
        total = md["total"]
    else:
        # fallback zeroes
        m = {"0-18": 0, "19-44": 0, "45-64": 0, "65+": 0}
        total = 0
    print(f'    "{cname}": {{')
    print(f'        "pop": {meta["pop"]}, "area": {meta["area"]},')
    print(f'        "medicaid": {{"0-18": {m["0-18"]}, "19-44": {m["19-44"]}, "45-64": {m["45-64"]}, "65+": {m["65+"]}}},')
    print(f'        "medicaid_total": {total}')
    print(f'    }},')
print("}")
